from django.urls import path, include
from .views import *

urlpatterns = [
    path("users/", UserView.as_view()),
    # Get User Details and create a room
    path("user/<int:pk>/", UserDetailsView.as_view()),
    path("welcomemsg-rooms/", WelcomeMsgView.as_view()),
    path("chatroom/", ChatRoomView.as_view()),
    # Path for private room url
    path("chatroom/<int:pk>/", WelcomeMsgDetails.as_view()),
]